# coding=utf-8
from uliweb import expose, functions, json, request
from StringIO import StringIO
import time,base64,os
"""ueditor文件上传配置文件"""
ue_config = {
    #图片上传配置
    "imageActionName": "upload_image"
    ,"imageFieldName": "upload_image"
    ,"imageMaxSize": 2048000
    ,"imageAllowFiles": [".png", ".jpg", ".jpeg", ".gif", ".bmp"]
    ,"imageCompressEnable": True
    ,"imageCompressBorder": 1600
    ,"imageInsertAlign": "none"
    ,"imageUrlPrefix": ""
    ,"imagePathFormat": ""

    #附件上传配置
    ,"fileActionName":"upload_attach"
    ,"fileFieldName":"upload_attach"
    ,"filePathFormat":""
    ,"fileUrlPrefix":""
    ,"fileMaxSize":2048000
    ,"fileAllowFiles":[
        ".png", ".jpg", ".jpeg", ".gif", ".bmp",
        ".flv", ".swf", ".mkv", ".avi", ".rm", ".rmvb", ".mpeg", ".mpg",
        ".ogg", ".ogv", ".mov", ".wmv", ".mp4", ".webm", ".mp3", ".wav", ".mid",
        ".rar", ".zip", ".tar", ".gz", ".7z", ".bz2", ".cab", ".iso",
        ".doc", ".docx", ".xls", ".xlsx", ".ppt", ".pptx", ".pdf", ".txt", ".md", ".xml"]

    #涂鸦上传配置
    ,"scrawlActionName": "upload_scrawl"
    ,"scrawlFieldName": "upload_scrawl"
    ,"scrawlPathFormat": ""
    ,"scrawlMaxSize": 2048000
    ,"scrawlUrlPrefix": ""
    ,"scrawlInsertAlign": "none"

    #UE工具栏配置,会覆盖前端config中的toolbars
    ,"toolbars": [[
            'fullscreen', 'source',
            '|',
            'undo', 'redo',
            '|',
			'bold', 'italic', 'underline', 'fontborder', 'strikethrough', 'superscript', 'subscript', 'removeformat', 'formatmatch', 'autotypeset', 'blockquote', 'pasteplain',
            '|',
            'forecolor', 'backcolor', 'insertorderedlist', 'insertunorderedlist', 'selectall', 'cleardoc',
            '|',
			'rowspacingtop', 'rowspacingbottom', 'lineheight',
            '|',
			'customstyle', 'paragraph', 'fontfamily', 'fontsize',
            '|',
			'directionalityltr', 'directionalityrtl', 'indent',
            '|',
			'justifyleft', 'justifycenter', 'justifyright', 'justifyjustify',
            '|',
            'touppercase', 'tolowercase',
            '|',
			'link', 'unlink', 'anchor',
            '|',
            'imagenone', 'imageleft', 'imageright', 'imagecenter',
            '|',
			'simpleupload', 'insertimage', 'scrawl', 'attachment', 'insertcode', 'pagebreak', 'template', 'background',
            '|',
			'horizontal', 'date', 'time', 'spechars',
            '|',
			'inserttable', 'deletetable', 'insertparagraphbeforetable', 'insertrow', 'deleterow', 'insertcol', 'deletecol', 'mergecells', 'mergeright', 'mergedown', 'splittocells', 'splittorows', 'splittocols', 'charts',
            '|',
            'searchreplace', 'drafts'
	]]
}


@expose('/api/upload')
class Upload(object):
    @expose('controller')
    def controller(self):
        this = self
        plugin = request.GET.get("plugin")
        action = request.GET.get("action")
        if plugin == 'ue' and action == "config":
            print "upload ===> config"
            config = ue_config
        elif plugin == 'ue' and action == 'upload_image':
            #UE上传单张图片
            print "upload ===> upload_image"
            config = self._upload_image()
        elif plugin == 'ue' and action == 'upload_attach':
            #UE上传附件
            print "upload ===> upload_attach"
            config = self._upload_attach()
        elif plugin == 'ue' and action == 'upload_scrawl':
            #UE上传涂鸦
            print "upload ===> upload_scrawl"
            config = self._upload_scrawl()
        return json(config)

    #根据GET参数配置文件存放路径
    def _get_path_and_filename(self):
        plugin = request.GET.get("plugin")
        action = request.GET.get("action").replace("upload_",'')
        path = "%s/%s/"%(action,plugin)
        login_user = request.cookies.get('flpm_login_username') or "no_login_user"
        filename = "%s_%s_%s_%s"%(plugin,action,login_user,str(int(time.time())))
        return {"filename":filename,"path":path}
    #涂鸦上传
    def _upload_scrawl(self):
        file_base64 = request.POST.get("upload_scrawl")
        data = self._get_path_and_filename()
        filename = data.get('filename')+".png"
        path = data.get("path")
        fobj = StringIO(base64.b64decode(file_base64))
        nname = functions.save_file(filename,fobj,subpath=path)
        print nname
        config = {
            "state":"SUCCESS",
            "url":"http://localhost:8001/uploads/"+path+nname,
            "title":"",
            "original":"",
            "type":"",
            "size":""
        }
        return config

    #附件上传
    def _upload_attach(self):
        request_files_dict = request.files.to_dict()
        file = request_files_dict.get("upload_attach")
        print type(file)
        data = self._get_path_and_filename()
        path = data.get('path')
        filename = data.get('filename')
        if file:
            save_file_name = functions.save_file(filename,file,subpath=path)
            print save_file_name
        config = {
            "state":"SUCCESS",
            "url":"http://localhost:8001/uploads/"+save_file_name,
            "title":"",
            "original":"",
            "type":"",
            "size":""
        }
        return config
    #图片上传（单张，多张都是此方法，前端UE会分别多次发起Ajax请求来发送图片，一次一张）
    def _upload_image(self):
        request_files_dict = request.files.to_dict()
        file = request_files_dict.get("upload_image")
        if file:
            save_file_name = functions.save_file(str(int(time.time()))+file.filename,file,subpath='images')
            print save_file_name
        config = {
                "state": "SUCCESS",
                "url": "http://localhost:8001/uploads/images/"+save_file_name,
                "title": "",
                "original": "",
                "type": "",
                "size": ""
            }
        return config

